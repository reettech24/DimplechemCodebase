import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash, faPlus } from "@fortawesome/free-solid-svg-icons";

const getAuthToken = () => localStorage.getItem("token");

const LocalEditOutTour = ({ setIslocalEditOutTourOpen }) => {
  //console.log("costWorkingData", costWorkingData);

  return (
    <>
      {/* Modal Container */}
      <div className="fixed inset-0 p-2 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white w-full md:w-[1400px]  rounded-[6px]">
          <h2 className="text-white text-[20px] font-poppins mb-2 px-0 py-2 text-center bg-bgDataNew rounded-t-[5px]">
            Edit Local Expenses
          </h2>

          {/* New Code */}
          {/* New Code */}
          <div className="p-4 mt-5 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* General Information */}
            <h3 className="-mb-0 text-black font-poppins border bg-gray-400 py-1 rounded-t-[4px] font-medium text-[20px] text-bgData mb-0 text-center mx-auto">
              DIMPLE CHEMICALS & SERVICES PVT LTD
              <br />
              <span className="text-gray-700 text-[18px]">
                OUTSTATION / LOCAL EXPENSES SHEET
              </span>
            </h3>

            <div className="border border-gray-400 mx-[2px]">
              <div className="w-100 flex items-start justify-between px-0">
                <div className="bg-[#e5e7eb38] rounded-[5px] w-[500px]">
                  <table className="w-full border border-gray-300 text-sm table-fixed">
                    <tbody>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600 w-[40%]">
                          Name of Employee
                        </td>
                        <td className="py-2 text-right align-middle w-[5%]">
                          :
                        </td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24 w-[40%]">
                          <input
                            type="text"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="Employee"
                            value="Rahul Sharma"
                          />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Period of Expenses
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          <input
                            type="text"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="person"
                            value="Demo"
                          />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Place of Visit
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          <input
                            type="text"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="place"
                            value="Indore"
                          />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Bank A/C No.
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          <input
                            type="date"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="period"
                            value="5"
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Materials Table */}
              <div className="relative ">
                <div className="absolute right-2 top-6">
                  <span className="bg-gray-500 text-white rounded-l-[5px] px-4 py-[6.2px] mr-[0.5px]">
                    Please click Plus Button to add the row
                  </span>
                  <button
                    type="button"
                    className="bg-bgDataNew text-white px-2 py-1 rounded-r-[5px] hover:bg-orange-600 "
                  >
                    <FontAwesomeIcon icon={faPlus} />
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto mt-16">
                {/* New Code */}
                <table className="min-w-full border border-gray-300">
                  <thead className="bg-gray-400">
                    <tr>
                      {[
                        "S.N.",
                        "Date",
                        "Particulars",
                        "Travelling Exp.",
                        "Loading & Boarding",
                        "Printing & Stationery",
                        "Food Expenses",
                        "Company Car Exp.",
                        "Purchases",
                        "Other",
                        "Total",
                        "Action",
                      ].map((header, index) => (
                        <th
                          key={index}
                          className={`border text-black border-gray-300 font-poopins font-medium text-[16px] px-4 py-2  ${
                            header === "S.N." ? "text-left" : "text-center"
                          } ${
                            header === "Loading & Boarding"
                              ? "w-[900px]"
                              : "text-center"
                          } 
                                      ${
                                        header === "Date"
                                          ? "w-[100px]"
                                          : "text-center"
                                      }
                                      ${
                                        header === "Travelling Exp."
                                          ? "w-[900px]"
                                          : "text-center"
                                      }
                                      ${
                                        header === "Printing & Stationery"
                                          ? "w-[900px]"
                                          : "text-center"
                                      }
                                      ${
                                        header === "Food Expenses"
                                          ? "w-[900px]"
                                          : "text-center"
                                      }
                                      ${
                                        header === "Company Car Exp."
                                          ? "w-[900px]"
                                          : "text-center"
                                      }
                                      ${
                                        header === "Particulars"
                                          ? "w-[900px]"
                                          : "text-center"
                                      }
                                      ${
                                        header === "Purchases"
                                          ? "w-[900px]"
                                          : "text-center"
                                      }
                                      ${
                                        header === "Other"
                                          ? "w-[900px]"
                                          : "text-center"
                                      }`}
                        >
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        1
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-center"
                        colSpan="1"
                      >
                        <input
                          type="date"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="Date"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="particular"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="Travelling Exp."
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="Loading & Boarding"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="printing & stationary"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="food expenses"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="company car expenses"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="purchases"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="other"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        45287
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <button
                          type="button"
                          className="bg-bgDataNew text-white px-2 py-1 rounded hover:bg-orange-600 "
                        >
                          <FontAwesomeIcon icon={faTrash} />
                        </button>
                      </td>
                    </tr>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left"
                        colSpan={2}
                      ></td>
                      <td
                        className="border font-semibold text-bgDataNew border-gray-300 px-4 py-2 text-textdata text-center w-[400px]"
                        colSpan="1"
                      >
                        Total:
                      </td>
                      <td className="border font-semibold text-gray-700 border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        0.00
                      </td>
                      <td className="border font-semibold text-gray-700 border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        0.00
                      </td>
                      <td className="border font-semibold text-gray-700 border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        0.00
                      </td>
                      <td className="border font-semibold text-gray-700 border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        0.00
                      </td>
                      <td className="border font-semibold text-gray-700 border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        0.00
                      </td>
                      <td className="border font-semibold text-gray-700 border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        0.00
                      </td>
                      <td className="border font-semibold text-gray-700 border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        0.00
                      </td>

                      <td className="border font-semibold text-bgDataNew border-gray-300 px-4 py-2 text-textdata text-center w-[400px]">
                        452009
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Submit and Close Buttons */}
          <div className="flex items-end justify-end gap-2 px-4 my-4">
            <button
              type="submit"
              className="bg-bgDataNew text-white px-3 py-2 rounded hover:bg-[#cb6f2ad9]"
            >
              Submit
            </button>
            <button
              type="button"
              className="bg-gray-500 text-white px-3 py-2 rounded hover:bg-gray-600"
              onClick={() => setIslocalEditOutTourOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default LocalEditOutTour;
