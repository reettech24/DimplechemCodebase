import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";

const getAuthToken = () => localStorage.getItem("token");

const ViewOutTour = ({
  setIsViewOutTourOpen
}) => {
  //console.log("costWorkingData", costWorkingData);
  

  return (
    <>

      {/* Modal Container */}
      <div className="fixed inset-0 p-2 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white w-full md:w-[1400px]  rounded-[6px]">
          <h2 className="text-white text-[20px] font-poppins mb-2 px-0 py-2 text-center bg-bgDataNew rounded-t-[5px]">
           View OutTour Expenses
          </h2>

          {/* New Code */}
          <div className="p-4 mt-5 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* General Information */}
            <h3 className="-mb-0 text-black font-poppins border bg-gray-400 py-1 rounded-t-[4px] font-medium text-[20px] text-bgData mb-0 text-center mx-auto">
              DIMPLE CHEMICALS & SERVICES PVT LTD
              <br />
              <span className="text-gray-700 text-[18px]">
                OUT TOUR EXPENSES APPROVAL
              </span>
            </h3>

            <div className="border border-gray-400 mx-[2px]">
              <div className="w-100 flex items-start justify-between px-0">
                <div className="bg-[#e5e7eb38] rounded-[5px] w-[500px]">
                  <table className="w-full border border-gray-300 text-sm table-fixed">
                    <tbody>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600 w-[40%]">
                          Name of Employee
                        </td>
                        <td className="py-2 text-right align-middle w-[5%]">
                          :
                        </td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24 w-[40%]">
                          Rahul Sharma
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Person Accompanied
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          Demo
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Place of Visit
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          Indore
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Period of Visit
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          01/07/25
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Materials Table */}
              <div className="overflow-x-auto mt-8">
                {/* New Code */}
                <table className="min-w-full border border-gray-300">
                  <thead className="bg-gray-400">
                    {/* Section Header: Material Cost */}
                    <tr className="bg-gray-300 text-center">
                      <td colSpan="9" className="py-2">
                        <div className="mb-1 border border-gray-400 w-fit mx-auto px-4 py-0 rounded-[3px] font-poppins font-medium text-[18px]  text-gray-700">
                          Details of Visit
                        </div>
                        <div className="border border-gray-400 w-fit mx-auto px-4 py-0 rounded-[3px] font-poppins font-medium text-[15px]  text-gray-600">
                          Expected Potential (In Rupees)
                        </div>
                      </td>
                    </tr>
                    <tr>
                      {[
                        "S.N.",
                        "Date",
                        "Place of Visit",
                        "Purpose of Visit",
                      ].map((header, index) => (
                        <th
                          key={index}
                          className={`border text-black border-gray-300 font-poopins font-medium text-[16px] px-4 py-2 ${
                            header === "S.N." ? "text-left" : "text-center"
                          }`}
                        >
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        1
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-center"
                        colSpan="1"
                      >
                       02/07/25
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        Indore
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        Project Realted Issues
                      </td>
                    </tr>
                  </tbody>
                </table>

                <table className="min-w-full border border-gray-300 mt-8">
                  <thead className="bg-gray-400">
                    {/* Section Header: Material Cost */}
                    <tr className="bg-gray-300 text-center">
                      <td colSpan="9" className="py-2">
                        <div className="border border-gray-400 w-fit mx-auto px-4 py-0 rounded-[3px] font-poppins font-medium text-[18px]  text-gray-700">
                          Expenses Budget
                        </div>
                      </td>
                    </tr>
                    <tr>
                      {["S.N.", "Description", "Amount"].map(
                        (header, index) => (
                          <th
                            key={index}
                            className={`border text-black border-gray-300 font-poopins font-medium text-[16px] px-4 py-2 ${
                              header === "S.N." ? "text-left" : "text-center"
                            }`}
                          >
                            {header}
                          </th>
                        )
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        1
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left pl-24 w-[500px]"
                        colSpan="1"
                      >
                       
                        TRAVELING EXP.
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                       123456
                      </td>
                    </tr>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        2
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left pl-24 w-[500px]"
                        colSpan="1"
                      >
                       
                        LODGING & BOARDING
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                       25455
                      </td>
                    </tr>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        3
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left pl-24 w-[500px]"
                        colSpan="1"
                      >
                       
                        PRINTING & STATIONERY
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                        25469
                      </td>
                    </tr>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        4
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left pl-24 w-[500px]"
                        colSpan="1"
                      >
                       
                        FOOD EXPENSES
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                       525845
                      </td>
                    </tr>
                     <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        5
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left pl-24 w-[500px]"
                        colSpan="1"
                      >
                       
                        COMPANY CAR EXP.
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                       147585
                      </td>
                    </tr>
                     <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        6
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left pl-24 w-[500px]"
                        colSpan="1"
                      >
                        
                        PURCHASES
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                       745896
                      </td>
                    </tr>
                     <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        7
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-left pl-24 w-[500px]"
                        colSpan="1"
                      >
                       
                        OTHER
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                       456974
                      </td>
                    </tr>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        
                      </td>
                      <td
                        className="border font-semibold border-gray-300 px-4 py-2 text-bgDataNew text-center w-[500px]"
                        colSpan="1"
                      >
                        Total
                      </td>
                      <td className="border font-semibold text-bgDataNew border-gray-300 px-4 py-2  text-center w-[500px]">
                        452009
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

            </div>
          </div>

          {/* Submit and Close Buttons */}
          <div className="flex items-end justify-end gap-2 px-4 my-4">
            <button
              type="submit"
              className="bg-bgDataNew text-white px-3 py-2 rounded hover:bg-[#cb6f2ad9]"
            >
              Submit
            </button>
            <button
              type="button"
              className="bg-gray-500 text-white px-3 py-2 rounded hover:bg-gray-600"
              onClick={() => setIsViewOutTourOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewOutTour;
