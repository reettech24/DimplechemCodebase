import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash, faPlus } from "@fortawesome/free-solid-svg-icons";

const getAuthToken = () => localStorage.getItem("token");

const EditOutTour = ({ setIsEditOutTourOpen }) => {
  //console.log("costWorkingData", costWorkingData);

  return (
    <>
      {/* Modal Container */}
      <div className="fixed inset-0 p-2 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white w-full md:w-[1400px]  rounded-[6px]">
          <h2 className="text-white text-[20px] font-poppins mb-2 px-0 py-2 text-center bg-bgDataNew rounded-t-[5px]">
            Edit OutTour Expenses
          </h2>

          {/* New Code */}
          {/* New Code */}
          <div className="p-4 mt-5 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* General Information */}
            <h3 className="-mb-0 text-black font-poppins border bg-gray-400 py-1 rounded-t-[4px] font-medium text-[20px] text-bgData mb-0 text-center mx-auto">
              DIMPLE CHEMICALS & SERVICES PVT LTD
              <br />
              <span className="text-gray-700 text-[18px]">
                OUT TOUR EXPENSES APPROVAL
              </span>
            </h3>

            <div className="border border-gray-400 mx-[2px]">
              <div className="w-100 flex items-start justify-between px-0">
                <div className="bg-[#e5e7eb38] rounded-[5px] w-[500px]">
                  <table className="w-full border border-gray-300 text-sm table-fixed">
                    <tbody>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600 w-[40%]">
                          Name of Employee
                        </td>
                        <td className="py-2 text-right align-middle w-[5%]">
                          :
                        </td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24 w-[40%]">
                          <input
                            type="text"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="Enter the Employee"
                            value="Rahul Sharma"
                          />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Person Accompanied
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          <input
                            type="text"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="Enter the person"
                            value="Demo"
                          />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Place of Visit
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          <input
                            type="text"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="Enter the place"
                            value="Indore"
                          />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="py-2 px-4 text-left font-bold text-gray-600">
                          Period of Visit
                        </td>
                        <td className="py-2 text-right align-middle">:</td>
                        <td className="py-2 px-4 text-left text-gray-800 pl-24">
                          <input
                            type="date"
                            className="w-full px-2 py-1 border border-gray-400 rounded"
                            placeholder="Enter the period"
                            value="5"
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Materials Table */}
              <div className="overflow-x-auto mt-8">
                {/* New Code */}
                <table className="min-w-full border border-gray-300">
                  <thead className="bg-gray-400">
                    {/* Section Header: Material Cost */}
                    <tr className="bg-gray-300 text-center">
                      <td colSpan="9" className="py-2 relative">
                        <div className="mb-1 border border-gray-400 w-fit mx-auto px-4 py-0 rounded-[3px] font-poppins font-medium text-[18px]  text-gray-700">
                          Details of Visit
                        </div>
                        <div className="border border-gray-400 w-fit mx-auto px-4 py-0 rounded-[3px] font-poppins font-medium text-[15px]  text-gray-600">
                          Expected Potential (In Rupees)
                        </div>
                        <div className="absolute right-4 top-4">
                          <button
                            type="button"
                            className="bg-bgDataNew text-white px-2 py-1 rounded hover:bg-orange-600 "
                          >
                            <FontAwesomeIcon icon={faPlus} />
                          </button>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      {[
                        "S.N.",
                        "Date",
                        "Place of Visit",
                        "Purpose of Visit",
                        "Action",
                        // "Qty for 1",
                        // "Std Pak",
                        // "Basic Rate",
                        // "Basic Amount",
                      ].map((header, index) => (
                        <th
                          key={index}
                          className={`border text-black border-gray-300 font-poopins font-medium text-[16px] px-4 py-2 ${
                            header === "S.N." ? "text-left" : "text-center"
                          }`}
                        >
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        1
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-center"
                        colSpan="1"
                      >
                        <input
                          type="date"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="Enter the Date"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="Enter the Place"
                          value="Indore"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <input
                          type="text"
                          className="w-full px-2 py-1 border border-gray-400 rounded"
                          placeholder="Enter the Purpose"
                          value="Project realted issues"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <button
                          type="button"
                          className="bg-bgDataNew text-white px-2 py-1 rounded hover:bg-orange-600 "
                        >
                          <FontAwesomeIcon icon={faTrash} />
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>

                <table className="min-w-full border border-gray-300 mt-8">
                  <thead className="bg-gray-400">
                    {/* Section Header: Material Cost */}
                    <tr className="bg-gray-300 text-center">
                      <td colSpan="9" className="py-2 relative">
                        <div className="border border-gray-400 w-fit mx-auto px-4 py-0 rounded-[3px] font-poppins font-medium text-[18px]  text-gray-700">
                          Expenses Budget
                        </div>
                         <div className="absolute right-4 top-2">
                                                  <button
                                                    type="button"
                                                    className="bg-bgDataNew text-white px-2 py-1 rounded hover:bg-orange-600 "
                                                  >
                                                    <FontAwesomeIcon icon={faPlus} />
                                                  </button>
                                                </div>
                      </td>
                    </tr>
                    <tr>
                      {["S.N.", "Description", "Amount", "Action"].map(
                        (header, index) => (
                          <th
                            key={index}
                            className={`border text-black border-gray-300 font-poopins font-medium text-[16px] px-4 py-2 ${
                              header === "S.N." ? "text-left" : "text-center"
                            }`}
                          >
                            {header}
                          </th>
                        )
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left">
                        1
                      </td>
                      <td
                        className="border border-gray-300 px-4 py-2 text-textdata text-center w-[400px]"
                        colSpan="1"
                      >
                        <select className="w-full px-2 py-[7px] border border-gray-400 rounded">
                          <option value="">Select the Address</option>
                          <option>TRAVELING EXP.</option>
                          <option>LODGING & BOARDING </option>
                          <option>PRINTING & STATIONERY</option>
                          <option>FOOD EXPENSES</option>
                          <option>COMPANY CAR EXP.</option>
                          <option>PURCHASES</option>
                          <option>OTHER</option>
                        </select>
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                        <input
                          type="number"
                          className="w-full px-2 py-1 border border-gray-300 rounded"
                          placeholder="Enter the number"
                          value="390720"
                        />
                      </td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-center">
                        <button
                          type="button"
                          className="bg-bgDataNew text-white px-2 py-1 rounded hover:bg-orange-600 "
                        >
                          <FontAwesomeIcon icon={faTrash} />
                        </button>
                      </td>
                    </tr>

                    <tr className="text-center hover:bg-gray-200 cursor-pointer">
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left"></td>
                      <td className="border border-gray-300 px-4 py-2 text-textdata text-left"></td>
                      <td
                        className="border font-semibold text-bgDataNew border-gray-300 px-4 py-2 text-textdata text-center w-[500px]"
                        colSpan="1"
                      >
                        Total
                      </td>
                      <td className="border font-semibold text-bgDataNew border-gray-300 px-4 py-2 text-textdata text-center w-[500px]">
                        452009
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Submit and Close Buttons */}
          <div className="flex items-end justify-end gap-2 px-4 my-4">
            <button
              type="submit"
              className="bg-bgDataNew text-white px-3 py-2 rounded hover:bg-[#cb6f2ad9]"
            >
              Submit
            </button>
            <button
              type="button"
              className="bg-gray-500 text-white px-3 py-2 rounded hover:bg-gray-600"
              onClick={() => setIsEditOutTourOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditOutTour;
