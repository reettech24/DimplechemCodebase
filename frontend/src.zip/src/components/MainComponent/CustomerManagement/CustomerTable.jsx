import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { listCustomers, removeCustomer } from "../../../redux/customerSlice";
import SuccessMessage from "../../AlertMessage/SuccessMessage";
import ErrorMessage from "../../AlertMessage/ErrorMessage";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPenToSquare } from "@fortawesome/free-regular-svg-icons";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import { useUserPermissionCheck } from "../../hooks/useUserPermissionCheck";

const CustomerTable = ({
  customers,
  setEditCustomerModalOpen,
  setViewModalOpen,
  selectedCustomer,
  setSelectedCustomer,
  setIsAssignModalOpen,
  deleteFlashMessage,
  deleteFlashMsgType,
  handleDeleteFlashMessage,
  handleDelete,
  userDeatail,
}) => {
  const navigate = useNavigate();

  const { hasPermission, isLoading, isError } = useUserPermissionCheck();

  if (isLoading) return <div>Loading permissions...</div>;
  if (isError) return <div>Error loading permissions</div>;
  //console.log("userDeatail", userDeatail);
  return (
    <>
       <style>
        {`
          .custom-scrollbar::-webkit-scrollbar {
            height: 10px;
            cursor: pointer;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background-color: #fe6c00c4 !important; 
            border-radius: 8px;
            cursor: pointer;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
            cursor: pointer;
          }

          /* For Firefox */
          .custom-scrollbar {
            scrollbar-width: thin;
            scrollbar-color: #68574c transparent;
            cursor: pointer;
          }
       `}
      </style>
      <div className="fixed top-5 right-5 z-50">
        {deleteFlashMessage && deleteFlashMsgType === "success" && (
          <SuccessMessage message={deleteFlashMessage} />
        )}
        {deleteFlashMessage && deleteFlashMsgType === "error" && (
          <ErrorMessage message={deleteFlashMessage} />
        )}
      </div>
      <div className="overflow-x-auto custom-scrollbar max-h-[360px]">
        <table className="table-auto w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#473b33] rounded-[8px] sticky top-0 z-10">
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                <input
                  type="checkbox"
                  disabled
                  className="w-4 h-4 accent-orange-500"
                />
              </th>
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                Id
              </th>
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                Cust Id
              </th>
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                Company Name
              </th>
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                Email
              </th>
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                Phone Number
              </th>
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                Secondary Number
              </th>
              <th className="px-4 py-2 text-left text-bgDataNew text-newtextdata whitespace-nowrap ">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {customers?.map((user, index) => (
              <tr key={index}>
                <td className="px-4 py-2 text-newtextdata whitespace-nowrap ">
                  <input
                    type="checkbox"
                    className="w-4 h-4 accent-orange-500"
                  />
                </td>
                <td className="px-4 py-2 text-newtextdata whitespace-nowrap ">00{index + 1}</td>
                <td className="px-4 py-2 text-newtextdata whitespace-nowrap ">
                  {user.cust_id}
                </td>
                <td
                  className="relative group px-4 py-2 text-newtextdata whitespace-nowrap cursor-pointer"
                  onClick={() => {
                    setSelectedCustomer(user);
                    setViewModalOpen(true);
                  }}
                >
                  {/* {user.company_name} */}
                   {(() => {
                    const companyName = user.company_name || "";
                    const words = companyName.split(" ");
                    return words.length > 2
                      ? `${words.slice(0, 2).join(" ")}...`
                      : companyName;
                  })()}

                  {/* Tooltip on hover */}
                  {(() => {
                    const companyName = user.company_name || "";
                    const words = companyName.split(" ");
                    const tooltipWidth =
                      words.length === 6 ? "w-[300px]" : "w-auto";

                    return (
                      <div
                        className={`absolute z-10 hidden group-hover:block bg-white text-gray-800 text-sm text-center rounded-md px-3 py-1 top-10 left-[75%] -translate-x-1/2 whitespace-normal ${tooltipWidth} shadow-lg text-center`}
                      >
                        {companyName}
                      </div>
                    );
                  })()}
                </td>
                <td className="px-4 py-2 text-newtextdata whitespace-nowrap ">
                  {user.email_id}
                </td>
                <td className="px-4 py-2 text-newtextdata whitespace-nowrap text-center">
                  {user.primary_contact}
                </td>
                <td className="px-4 py-2 text-newtextdata whitespace-nowrap text-center">
                  {user.primary_contact}
                </td>
                <td className="px-4 py-2 text-newtextdata whitespace-nowrap  space-x-2 text-center">
                  {hasPermission(3, 4) && (
                    <button
                      className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
                      onClick={() => {
                        setSelectedCustomer(user);
                        setViewModalOpen(true);
                      }}
                    >
                      <FontAwesomeIcon icon={faEye} />
                    </button>
                  )}

                  {/* {userDeatail?.employeeRole?.role_id !== 3 && ( */}
                  <>
                    {hasPermission(3, 2) && (
                      <button
                        className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600 mr-2"
                        onClick={() => {
                          setSelectedCustomer(user);
                          setEditCustomerModalOpen(true);
                        }}
                      >
                        <FontAwesomeIcon icon={faPenToSquare} />
                      </button>
                    )}

                    {hasPermission(3, 3) && (
                      <button
                        className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                        onClick={() => {
                          if (
                            window.confirm(
                              "Are you sure you want to delete this customer?"
                            )
                          ) {
                            handleDelete(user.id);
                          }
                        }}
                      >
                        <FontAwesomeIcon icon={faTrash} />
                      </button>
                    )}
                  </>
                  {/* )} */}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default CustomerTable;
